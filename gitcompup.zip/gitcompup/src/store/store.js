import {createStore, combineReducers}   from 'redux';



export const store = createStore(
  combineReducers({
   
  })
);

store.subscribe(()=>console.log('state: ', store.getState()));