export const gridStyleSider = {
    width: '100%',
    height: '100vh',
    textAlign: 'center',
    background: 'green'
  };
   
    export const gridStyleHeader = {
      width: '100%',
      height: '10%',
      textAlign: 'center',
      background: '#4B9B00',
      textColor : 'white',
    };
    
    export const gridStyleContent = {
      width: '100%',
      textAlign: 'center',
      background: '#C8DED6',
      height: '100%'
    };
    
    export const gridStyleLayout1 = {
      width: '100%',
      textAlign: 'center',
      background: 'white',
    }; 
  
  
    export const styleCard = {
      
      background: 'white',
     // textcolor: 'green',
     // textcolor: '#00FF00',
      textColor: "green",
      color: "green",
      font: "#363636" ,
      height: "100%",
      borderColor: "#DAA520",
      borderRadius: "1"
      
    }; 