import http from "../http-common";


class BackDataService {

  getAllNews() {
    return http.get("/news");
  }


  testNews (idNews, title,newsCategoryId, text ){
    var body = {
      id: 'value',
      title: 'title',
      newsCategoryId: 'dnewsCategoryId'
  };
    const requestOptions = {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: body
    };
    console.log("NEW =", newsCategoryId);
    return fetch(``, body)
     // .then(handleResponse)
      .then(user => {
  
        return user;
      });     
  }

  createNews (title,newsCategoryId, text, show, date){
  //  console.log("CREATE NEWS POst SERVICE idNews=", isView);
    var body = {
      id: 'value',
      title: 'title',
      newsCategoryId: 'dnewsCategoryId'
  };
    const requestOptions = {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: body
    };
    return fetch(``, body)
     // .then(handleResponse)
      .then(user => {
  
        return user;
      });     
  }

}

export default new BackDataService();